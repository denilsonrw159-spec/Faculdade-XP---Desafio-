
'''
Módulo: produto_service.py

Descrição:
    Implementa a camada de serviço (Service Layer) para a entidade Produto.
    É responsável pela lógica de negócio, validação e coordenação entre
    as camadas Controller e Repository.

Camada: Service (no padrão MVC)
Relacionamentos:
    - Model: Produto (models/produto.py)
    - Repository: ProdutoRepository (repository/produto_repo.py)
    - Controller: produto_controller.py / produto_web.py

Responsabilidades:
    - Centralizar as regras de negócio da aplicação;
    - Garantir que dados válidos sejam enviados ao repositório;
    - Orquestrar operações de CRUD entre Controller e Repository;
    - Possibilitar reuso de lógica entre rotas (API e Web).

Padrões adotados:
    - Service Layer Pattern;
    - Dependency Injection (instancia o Repository internamente);
    - Separação entre lógica de negócio e persistência.

'''

# service/produto_service.py
from models.produto import Produto
from repository.produto_repo import ProdutoRepository

class ProdutoService:
    #Inicializa o serviço e cria uma instância do repositório.
    def __init__(self):
        self.repo = ProdutoRepository()

    #CREATE (Regra de negócio para criação de produto)
    def criar_produto(self, nome, preco, estoque):
        novo = Produto(nome=nome, preco=preco, estoque=estoque)
        return self.repo.salvar(novo)

    # READ (Consultas)
    def listar_todos(self):
        return self.repo.listar_todos()

    def buscar_por_id(self, id):
        return self.repo.buscar_por_id(id)

    def buscar_por_nome(self, nome):
        return self.repo.buscar_por_nome(nome)

    # UPDATE (Regras de atualização)
    def atualizar(self, id, nome, preco, estoque):
        return self.repo.atualizar(id, Produto(nome=nome, preco=preco, estoque=estoque))

    # DELETE (Remoção)
    def deletar(self, id):
        self.repo.deletar(id)

    # COUNT (Estatística simples)
    def contar(self):
        return self.repo.contar()
