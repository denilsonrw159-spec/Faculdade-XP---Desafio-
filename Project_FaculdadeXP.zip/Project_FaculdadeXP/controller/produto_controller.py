
"""
    Controlador responsável pelas rotas REST (API) do domínio Produto.
    Implementa os endpoints da API RESTful utilizando o padrão MVC,
    conectando a camada Controller à camada Service.

Camada: Controller (no padrão MVC)
Relacionamentos:
    - Service: ProdutoService (service/produto_service.py)
    - Model: Produto (model/produto.py)
    - View: JSON (retorno das respostas para o cliente HTTP)

Fluxo geral:
    1. Recebe requisições HTTP de clientes (Postman, sistemas externos, etc.);
    2. Encaminha as requisições à camada de serviço (Service);
    3. Retorna respostas JSON com dados, mensagens e códigos HTTP apropriados.

Padrões e práticas adotadas:
    - Arquitetura RESTful;
    - Blueprint do Flask para modularização das rotas;
    - Retornos JSON padronizados;
    - Códigos de status HTTP adequados (200, 201, 400, 404);
    - Docstrings em todas as funções.
=====================================================================
"""

from flask import Blueprint, jsonify, request
from services.produto_service import ProdutoService

# Inicialização do Blueprint e do serviço
produto_api = Blueprint('produto_api', __name__)
service = ProdutoService()

# ROTAS API REST

@produto_api.route('/produtos', methods=['GET'])
def listar_produtos():
    """Retorna todos os produtos em formato JSON."""
    produtos = service.listar_todos()
    return jsonify([p.to_dict() for p in produtos])


@produto_api.route('/produtos/<int:id>', methods=['GET'])
def buscar_por_id(id):
    """Retorna um produto específico pelo ID."""
    produto = service.buscar_por_id(id)
    if produto:
        return jsonify(produto.to_dict())
    return jsonify({'erro': 'Produto não encontrado'}), 404


@produto_api.route('/produtos/nome/<string:nome>', methods=['GET'])
def buscar_por_nome(nome):
    """Busca produtos por nome."""
    produtos = service.buscar_por_nome(nome)
    return jsonify([p.to_dict() for p in produtos])


@produto_api.route('/produtos/contar', methods=['GET'])
def contar_produtos():
    """Retorna o total de produtos cadastrados."""
    return jsonify({'total': service.contar()})


@produto_api.route('/produtos', methods=['POST'])
def criar_produto():
    """Cria um novo produto via JSON."""
    dados = request.json
    if not dados or not all(k in dados for k in ('nome', 'preco', 'estoque')):
        return jsonify({'erro': 'JSON inválido ou campos ausentes'}), 400

    produto = service.criar_produto(dados['nome'], dados['preco'], dados['estoque'])
    return jsonify(produto.to_dict()), 201


@produto_api.route('/produtos/<int:id>', methods=['PUT'])
def atualizar_produto(id):
    """Atualiza os dados de um produto via API."""
    dados = request.json
    produto = service.atualizar(id, dados['nome'], dados['preco'], dados['estoque'])
    if produto:
        return jsonify(produto.to_dict())
    return jsonify({'erro': 'Produto não encontrado'}), 404


@produto_api.route('/produtos/<int:id>', methods=['DELETE'])
def deletar_produto(id):
    """Remove um produto pelo ID."""
    service.deletar(id)
    return jsonify({"mensagem": f"Produto {id} excluído com sucesso."}), 200
