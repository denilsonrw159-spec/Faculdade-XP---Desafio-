''''
Descrição:
    Controlador responsável pelas rotas WEB (interface HTML)
    do domínio Produto. Implementa as páginas do sistema CRUD
    utilizando Flask e o padrão MVC (Model–View–Controller).

Camada: Controller (MVC)
Relacionamentos:
    - Service: ProdutoService (service/produto_service.py)
    - Model: Produto (model/produto.py)
    - Views: Templates HTML (templates/*.html)

Fluxo geral:
    1. Recebe requisições HTTP do navegador (usuário final);
    2. Interage com a camada de serviço para acessar dados;
    3. Renderiza templates HTML para exibição;
    4. Realiza redirecionamentos entre as páginas.

Padrões e boas práticas adotadas:
    - Uso de Blueprint para modularizar rotas;
    - Separação entre lógica de negócio (Service) e interface (View);
    - Uso de templates dinâmicos Jinja2;
    - Validação simples de dados recebidos em formulários HTML;
    - Retornos HTTP adequados (200, 302, 404).
=====================================================================
'''

from flask import Blueprint, render_template, request, redirect, url_for
from services.produto_service import ProdutoService

produto_web = Blueprint('produto_web', __name__)
service = ProdutoService()

# ========== ROTAS WEB (HTML) ==========

@produto_web.route('/')
def home():
    """Página inicial → redireciona para listagem."""
    return redirect(url_for('produto_web.listar_produtos_web'))


@produto_web.route('/produtos/web')
def listar_produtos_web():
    """Lista todos os produtos em uma tabela HTML."""
    produtos = service.listar_todos()
    return render_template('listar.html', produtos=produtos)


@produto_web.route('/produtos/web/cadastrar', methods=['GET', 'POST'])
def cadastrar_produto_web():
    """Formulário HTML para cadastrar um novo produto."""
    if request.method == 'POST':
        nome = request.form['nome']
        preco = float(request.form['preco'])
        estoque = int(request.form['estoque'])
        service.criar_produto(nome, preco, estoque)
        return redirect(url_for('produto_web.listar_produtos_web'))
    return render_template('cadastrar.html')


@produto_web.route('/produtos/web/editar/<int:id>', methods=['GET', 'POST'])
def editar_produto_web(id):
    """Formulário HTML para editar um produto existente."""
    produto = service.buscar_por_id(id)
    if not produto:
        return "Produto não encontrado", 404

    if request.method == 'POST':
        nome = request.form['nome']
        preco = float(request.form['preco'])
        estoque = int(request.form['estoque'])
        service.atualizar(id, nome, preco, estoque)
        return redirect(url_for('produto_web.listar_produtos_web'))

    return render_template('editar.html', produto=produto)


@produto_web.route('/produtos/web/excluir/<int:id>', methods=['POST'])
def excluir_produto_web(id):
    """Exclui um produto via interface web."""
    service.deletar(id)
    return redirect(url_for('produto_web.listar_produtos_web'))
