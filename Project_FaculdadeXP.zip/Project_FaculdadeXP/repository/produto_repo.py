
'''
#Teste local - sem banco
class ProdutoRepository:
    def __init__(self):
        self.produtos = []
        self.next_id = 1

    def salvar(self, produto):
        produto.id = self.next_id
        self.next_id += 1
        self.produtos.append(produto)
        return produto

    def listar_todos(self):
        return self.produtos

    def buscar_por_id(self, id):
        return next((p for p in self.produtos if p.id == id), None)

    def buscar_por_nome(self, nome):
        return [p for p in self.produtos if nome.lower() in p.nome.lower()]

    def atualizar(self, id, novo_produto):
        produto = self.buscar_por_id(id)
        if produto:
            produto.nome = novo_produto.nome
            produto.preco = novo_produto.preco
            produto.estoque = novo_produto.estoque
            return produto
        return None

    def deletar(self, id):
        self.produtos = [p for p in self.produtos if p.id != id]

    def contar(self):
        return len(self.produtos)
'''
#==========================================================================
'''
Descrição:
    Implementa a camada de acesso a dados (Repository) para a entidade Produto.
    É responsável por todas as operações diretas com o banco de dados,
    isolando a lógica de persistência da lógica de negócio (Service).

Camada: Repository (no padrão MVC)
Relacionamentos:
    - Model: Produto (models/produto.py)
    - Service: ProdutoService (service/produto_service.py)
    - Banco de dados: SQLite via SQLAlchemy (extensions.db)

Responsabilidades:
    - Inserir, atualizar, consultar e remover registros da tabela `produtos`;
    - Abstrair o acesso ao banco, evitando SQL explícito no restante da aplicação;
    - Garantir consistência das transações (commit/rollback).

Padrões adotados:
    - Repository Pattern (separa lógica de dados da lógica de negócio);
    - ORM (Object-Relational Mapping) com SQLAlchemy;
    - Transações explícitas via db.session.commit().
'''

#BANDO DE DADOS INTEGRADO

from extensions import db
from models.produto import Produto

class ProdutoRepository:
    # CREATE (INSERT)
    def salvar(self, produto: Produto) -> Produto:
        db.session.add(produto)
        db.session.commit()
        return produto

    #READ(SELECT)
    def listar_todos(self):
        return Produto.query.order_by(Produto.id.asc()).all()

    def buscar_por_id(self, id: int):
        return Produto.query.get(id)

    def buscar_por_nome(self, nome: str):
        return Produto.query.filter(Produto.nome.ilike(f"%{nome}%")).all()

    #UPDATE (UPDATE)
    def atualizar(self, id: int, novo: Produto):
        existente = self.buscar_por_id(id)
        if not existente:
            return None
        existente.nome = novo.nome
        existente.preco = novo.preco
        existente.estoque = novo.estoque
        db.session.commit()
        return existente

    # DELETE (REMOVE)
    def deletar(self, id: int):
        existente = self.buscar_por_id(id)
        if existente:
            db.session.delete(existente)
            db.session.commit()

    #COUNT(EXTRA)
    def contar(self) -> int:
        return Produto.query.count()
